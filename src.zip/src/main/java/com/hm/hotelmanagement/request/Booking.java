package com.hm.hotelmanagement.request;


import java.util.ArrayList;

public class Booking {

    public int guestId;

    public int bookingId;
    public String name;
    public Address address;
    public String contactNo;
    public String contactEmail;
    public String fromDate;
    public String toDate;
    public int currentStatus;
    public String reservationDate;
    public int numberOfRooms;
    public int roomType;
    public float payment;
    public float currentBalance;
    public String remark;

    public String emergencyContact;

    public PaymentTransactions paymentTransactions;

    public String allocatedRoomList;

    public ArrayList<DocumentDetails> documentDetails;

    public ArrayList<DocumentDetails> getDocumentDetails() {
        return documentDetails;
    }

    public void setDocumentDetails(ArrayList<DocumentDetails> documentDetails) {
        this.documentDetails = documentDetails;
    }

    public String getAllocatedRoomList() {
        return allocatedRoomList;
    }

    public void setAllocatedRoomList(String allocatedRoomList) {
        this.allocatedRoomList = allocatedRoomList;
    }

    public PaymentTransactions getPaymentTransactions() {
        return paymentTransactions;
    }

    public void setPaymentTransactions(PaymentTransactions paymentTransactions) {
        this.paymentTransactions = paymentTransactions;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public void setCurrentStatus(int currentStatus) {
        this.currentStatus = currentStatus;
    }

    public void setReservationDate(String reservationDate) {
        this.reservationDate = reservationDate;
    }

    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    public void setRoomType(int roomType) {
        this.roomType = roomType;
    }

    public void setPayment(float payment) {
        this.payment = payment;
    }

    public void setCurrentBalance(float currentBalance) {
        this.currentBalance = currentBalance;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Address getAddress() {
        return address;
    }

    public int getGuestId() {
        return guestId;
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getName() {
        return name;
    }

    public String getContactNo() {
        return contactNo;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public String getFromDate() {
        return fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public int getCurrentStatus() {
        return currentStatus;
    }

    public String getReservationDate() {
        return reservationDate;
    }

    public int getNumberOfRooms() {
        return numberOfRooms;
    }

    public int getRoomType() {
        return roomType;
    }

    public float getPayment() {
        return payment;
    }

    public float getCurrentBalance() {
        return currentBalance;
    }

    public String getRemark() {
        return remark;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "guestId=" + guestId +
                ", bookingId=" + bookingId +
                ", name='" + name + '\'' +
                ", address=" + address +
                ", contactNo='" + contactNo + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", fromDate='" + fromDate + '\'' +
                ", toDate='" + toDate + '\'' +
                ", currentStatus=" + currentStatus +
                ", reservationDate='" + reservationDate + '\'' +
                ", numberOfRooms=" + numberOfRooms +
                ", roomType=" + roomType +
                ", payment=" + payment +
                ", currentBalance=" + currentBalance +
                ", remark='" + remark + '\'' +
                ", emergencyContact='" + emergencyContact + '\'' +
                '}';
    }
}

package com.hm.hotelmanagement.request;

import java.util.ArrayList;

public class Review {

    public int days;
    public boolean isMax;
    public String keyword;

    public ArrayList<ReviewReport> reviewReports;

    public ArrayList<ReviewReport> getReviewReports() {
        return reviewReports;
    }

    public void setReviewReports(ArrayList<ReviewReport> reviewReports) {
        this.reviewReports = reviewReports;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public boolean isMax() {
        return isMax;
    }

    public void setMax(boolean max) {
        isMax = max;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}

package com.hm.hotelmanagement.controller;

import com.hm.hotelmanagement.bl.BookingBL;
import com.hm.hotelmanagement.request.Booking;
import com.hm.hotelmanagement.request.PaymentTransactions;
import com.hm.hotelmanagement.request.RoomAvailability;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BookingController {

    @Autowired
    BookingBL bookingBL;
    @RequestMapping(value = "/booking", method = RequestMethod.POST)
    public Booking addUser(@RequestBody Booking booking) {
        System.out.println("Booking request : " + booking);
        bookingBL.createBooking(booking);
        return booking;
    }

    @RequestMapping(value = "/availability", method = RequestMethod.POST)
    public List<RoomAvailability> availabilityCheck(@RequestBody Booking booking) {
        System.out.println("Booking request : " + booking);
        List<RoomAvailability> list = bookingBL.availability(booking);
        return list;
    }

    @RequestMapping(value = "/payments", method = RequestMethod.POST)
    public PaymentTransactions payments(@RequestBody PaymentTransactions paymentTransactions) {
        System.out.println("PaymentTransactions request : " + paymentTransactions);
        paymentTransactions = bookingBL.createPayment(paymentTransactions, false);
        return paymentTransactions;
    }

    @RequestMapping(value = "/getPayments", method = RequestMethod.POST)
    public ArrayList<PaymentTransactions> getPayments(@RequestBody PaymentTransactions paymentTransactions) {
        System.out.println("PaymentTransactions request : " + paymentTransactions);
        ArrayList<PaymentTransactions> paymentTransactionsList = bookingBL.getPayments(paymentTransactions);
        return paymentTransactionsList;
    }

    @RequestMapping(value = "/fetch", method = RequestMethod.POST)
    public ArrayList<Booking> getBooking(@RequestBody Booking booking) {
        ArrayList<Booking> list = bookingBL.getBookingDetails(booking);
        return list;
    }

    @RequestMapping(value = "/checkin", method = RequestMethod.POST)
    public Booking checkIn(@RequestBody Booking booking) {
        booking = bookingBL.checkIn(booking);
        return booking;
    }

    @RequestMapping(value = "/checkout", method = RequestMethod.POST)
    public Booking checkOut(@RequestBody Booking booking) {
        booking = bookingBL.checkOutOrCancel(booking);
        return booking;
    }

}

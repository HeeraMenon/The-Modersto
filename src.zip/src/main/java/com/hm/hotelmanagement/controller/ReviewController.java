package com.hm.hotelmanagement.controller;

import com.hm.hotelmanagement.bl.ReviewBL;
import com.hm.hotelmanagement.request.Booking;
import com.hm.hotelmanagement.request.Review;
import com.hm.hotelmanagement.request.ReviewReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ReviewController {
    @Autowired
    ReviewBL reviewBL;

    @RequestMapping(value = "/getReport", method = RequestMethod.POST)
    public Review getReport(@RequestBody Review review) {
        System.out.println("review request : " + review);
        reviewBL.getReviews(review);
        return review;
    }

    @RequestMapping(value = "/createReport", method = RequestMethod.POST)
    public ReviewReport createReport(@RequestBody ReviewReport review) {
        System.out.println("review request : " + review);
        reviewBL.createReview(review);
        return review;
    }
}

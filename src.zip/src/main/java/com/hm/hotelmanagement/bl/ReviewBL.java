package com.hm.hotelmanagement.bl;

import com.hm.hotelmanagement.entity.RatingQuestions;
import com.hm.hotelmanagement.entity.ReviewAnswers;
import com.hm.hotelmanagement.repository.ReviewDetailsRepository;
import com.hm.hotelmanagement.repository.ReviewQuestionRepository;
import com.hm.hotelmanagement.request.Review;
import com.hm.hotelmanagement.request.ReviewReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Service
public class ReviewBL {

    @Autowired
    ReviewDetailsRepository reviewDetailsRepository;

    @Autowired
    ReviewQuestionRepository reviewQuestionRepository;

    public Review getReviews(Review review) {
        ArrayList<ReviewReport> reviewReports = new ArrayList<>();
        RatingQuestions question = reviewQuestionRepository.findByKeyWord(review.getKeyword());
        List<ReviewAnswers> reportList = null;
        if (review.isMax) {
            reportList = reviewDetailsRepository.getMaxReport(question.getId());

        } else {
            Date toDate = new Date(System.currentTimeMillis());
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, (-1 * review.getDays()));
            Date fromDate = new Date(cal.getTimeInMillis());
            System.out.println("fromDate :- " + fromDate + " toDate :- " + toDate);
            reportList = reviewDetailsRepository.getReport(question.getId(), fromDate, toDate);
        }
        for (ReviewAnswers reviewAnswers : reportList) {
            ReviewReport reviewReport = new ReviewReport();
            reviewReport.setDate(reviewAnswers.getDate() + "");
            reviewReport.setRating(reviewAnswers.getRating());
            reviewReport.setKeyword(review.getKeyword());
            reviewReport.setQuestionId(reviewAnswers.getQuestion_id());
            reviewReports.add(reviewReport);
        }

        review.setReviewReports(reviewReports);
        return review;
    }

    public ReviewReport createReview(ReviewReport reviewReport){

        ReviewAnswers reviewAnswers = new ReviewAnswers();
        reviewAnswers.setDate(new Date(System.currentTimeMillis()));
        reviewAnswers.setBooking_id(reviewReport.getBookingId());
        reviewAnswers.setGuest_id(reviewReport.getGuestId());
        reviewAnswers.setRating(reviewReport.getRating());
        reviewAnswers.setQuestion_id(reviewReport.getQuestionId());
        reviewAnswers = reviewDetailsRepository.save(reviewAnswers);
        return reviewReport;
    }
}

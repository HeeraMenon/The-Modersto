package com.hm.hotelmanagement.bl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.hm.hotelmanagement.entity.*;
import com.hm.hotelmanagement.repository.*;
import com.hm.hotelmanagement.request.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class BookingBL {

    public static int BOOKED =1;
    public static int CHECK_IN = 2;
    public static int CHECK_OUT=3;
    public static int CANCEL = 4;

    @Autowired
    private AddressDetailsRepository addressDetailsRepository;

    @Autowired
    GuestDetailsRepository guestDetailsRepository;

    @Autowired
    BookingDetailsRepository bookingDetailsRepository;

    @Autowired
    RoomDetailsRepository roomDetailsRepository;

    @Autowired
    PaymentTransactionRepository paymentTransactionRepository;

    @Autowired
    IdentificationDocumentRepository identificationDocumentRepository;

    @Autowired
    RoomAllocationDetailsRepository roomAllocationDetailsRepository;


    public Booking createBooking(Booking booking) {

        //Save the address details
        AddressDetails addressDetails = new AddressDetails();
        addressDetails.setCity(booking.getAddress().getCity());
        addressDetails.setCountry(booking.getAddress().getCountry());
        addressDetails.setZip(booking.getAddress().getZip());
        addressDetails.setLine1(booking.getAddress().getLine1());
        addressDetails.setLine2(booking.getAddress().getLine2());
        addressDetails.setLine3(booking.getAddress().getLine3());
        addressDetails = addressDetailsRepository.save(addressDetails);

        //Save the Guest details
        GuestDetails guestDetails = new GuestDetails();
        guestDetails.setAddress_id(addressDetails.getId());
        guestDetails.setContact_email(booking.getContactEmail());
        guestDetails.setName(booking.getName());
        guestDetails.setContact_no(booking.getContactNo());
        guestDetails.setEmergency_contact(booking.getEmergencyContact());
        guestDetails.setCreated_date(new java.sql.Date(System.currentTimeMillis()));
        guestDetails = guestDetailsRepository.save(guestDetails);

        //Save the booking details
        BookingDetails bookingDetails = new BookingDetails();
        bookingDetails.setCurrent_balance(booking.getCurrentBalance());
        bookingDetails.setNumber_of_rooms(booking.getNumberOfRooms());
        bookingDetails.setFrom_date(Date.valueOf(booking.getFromDate()));
        bookingDetails.setTo_date(Date.valueOf(booking.getToDate()));
        bookingDetails.setRoom_type(booking.getRoomType());
        bookingDetails.setGuest_id(guestDetails.guest_id);
        bookingDetails.setCurrent_status(BOOKED);
        bookingDetails.setReservation_date(new java.sql.Date(System.currentTimeMillis()));
        bookingDetails = bookingDetailsRepository.save(bookingDetails);

        //Check and update payments
        if (booking.getPaymentTransactions() == null) {
            booking.setPaymentTransactions(new PaymentTransactions());
        }
        booking = getRentAmount(booking);
        booking.getPaymentTransactions().setBookingId(bookingDetails.getId());
        booking.getPaymentTransactions().setGuestId(guestDetails.getGuest_id());
        booking.setPaymentTransactions(createPayment(booking.getPaymentTransactions(), true));
        bookingDetails.setPayment_transaction_id(booking.getPaymentTransactions().getPaymentId());
        bookingDetails.setCurrent_balance(booking.getPaymentTransactions().getBalanceAmount());
        bookingDetails = bookingDetailsRepository.save(bookingDetails);

        //Set the auto generated booking id and guest id to the response
        booking.setBookingId(bookingDetails.getId());
        booking.setGuestId(guestDetails.getGuest_id());
        return booking;
    }

    private Booking getRentAmount(Booking booking) {
        RoomDetails roomType = roomDetailsRepository.getById(booking.getRoomType());
        booking.setCurrentBalance(roomType.getRent() * booking.getNumberOfRooms());
        return  booking;
    }


    public PaymentTransactions createPayment(PaymentTransactions paymentTransactions, boolean isFirstRequest){

        PaymentTransactionDetails paymentTransactionDetails = new PaymentTransactionDetails();
        paymentTransactionDetails.setBooking_id(paymentTransactions.getBookingId());
        paymentTransactionDetails.setAmount(paymentTransactions.getAmount());
        paymentTransactionDetails.setPayment_mode(paymentTransactions.getPaymentMode());
        paymentTransactions.setBalanceAmount(computeBalanceAmount(paymentTransactions, isFirstRequest));
        paymentTransactionDetails.setBalance_amount( paymentTransactions.getBalanceAmount());
        paymentTransactionDetails.setGuest_id(paymentTransactions.getGuestId());
        paymentTransactionDetails.setRemark(paymentTransactions.getRemark());
        paymentTransactionDetails.setPayment_date(new Date(System.currentTimeMillis()));

        paymentTransactionDetails = paymentTransactionRepository.save(paymentTransactionDetails);
        paymentTransactions.setPaymentId(paymentTransactionDetails.getId());
        return paymentTransactions;
    }

    private float computeBalanceAmount(PaymentTransactions paymentTransactionDetails, boolean isFirstRequest) {

        if (isFirstRequest) {
            return paymentTransactionDetails.getBalanceAmount() - paymentTransactionDetails.getAmount();
        } else {
            BookingDetails booking = bookingDetailsRepository.getById(paymentTransactionDetails.getBookingId());
            PaymentTransactionDetails payment = paymentTransactionRepository.getById(booking.getPayment_transaction_id());
            return payment.getBalance_amount() - paymentTransactionDetails.getAmount();
        }
    }

    public List<RoomAvailability> availability(Booking booking) {
        List<BookingDetails> list = bookingDetailsRepository.findByDate(Date.valueOf(booking.getFromDate()), Date.valueOf(booking.getToDate()));
        System.out.println(list);
        List<RoomDetails> rooms = roomDetailsRepository.findAll();
        List<RoomAvailability> roomAvailabilityList = new ArrayList<>();
        if (booking.getRoomType() > 0) {
            //With room type check
            for (RoomDetails roomDetails : rooms) {
                if (roomDetails.getType() == booking.getRoomType()) {
                    RoomAvailability roomAvailability = new RoomAvailability();
                    roomAvailability.setFromDate(booking.getFromDate());
                    roomAvailability.setToDate(booking.getToDate());
                    roomAvailability.setRoomCount(roomDetails.getRoom_count() - getCount(list, roomDetails.getType()));
                    roomAvailability.setRoomType(roomDetails.getType());
                    roomAvailability.setSeries(roomDetails.getSeries());
                    roomAvailability.setCapacity(roomDetails.getCapacity());
                    roomAvailabilityList.add(roomAvailability);
                    break;

                }
            }
        }else {
            //Without room type
            for (RoomDetails roomDetails : rooms) {
                RoomAvailability roomAvailability = new RoomAvailability();
                roomAvailability.setFromDate(booking.getFromDate());
                roomAvailability.setToDate(booking.getToDate());
                roomAvailability.setRoomCount(roomDetails.getRoom_count() - getCount(list, roomDetails.getType()));
                roomAvailability.setRoomType(roomDetails.getType());
                roomAvailability.setSeries(roomDetails.getSeries());
                roomAvailability.setCapacity(roomDetails.getCapacity());
                roomAvailabilityList.add(roomAvailability);
            }
        }
        return roomAvailabilityList;
    }

    private int getCount(List<BookingDetails> list, int type) {
        int count = 0;
        for (BookingDetails bookingDetails : list) {
            if (bookingDetails.getRoom_type() == type) {
                count += bookingDetails.getNumber_of_rooms();
            }
        }
        return count;
    }

    public  ArrayList<Booking>  getBookingDetails(Booking booking){
        ArrayList<Booking> bookingList = new ArrayList<>();
        if(booking.getBookingId() > 0 ){
            // Search by booking id
            System.out.println("getBookingId :-> " + booking.getBookingId());
            Optional<BookingDetails> bookingOptional = bookingDetailsRepository.findById(booking.getBookingId());
            BookingDetails bookingDetails =  bookingOptional.get();
            if(bookingDetails!=null ){
                Optional<GuestDetails> opt = guestDetailsRepository.findById(bookingDetails.getGuest_id());
                GuestDetails guestDetails = opt.get();
                AddressDetails adrOpt = addressDetailsRepository.getById(guestDetails.getAddress_id());
                Booking bookingObj = convertObject(bookingDetails, guestDetails, adrOpt);
                bookingList.add(bookingObj);
                
            }
        }else if (booking.getName() !=null) {
            //search by name
            System.out.println("Name :-> " + booking.getName());
            List<BookingDetails> bookings = bookingDetailsRepository.findAll();
            List<GuestDetails> guestList = guestDetailsRepository.findByName(booking.getName());
            System.out.println("guestList :-> " + guestList);
            for (GuestDetails guestDetails : guestList) {
                AddressDetails adrOpt = addressDetailsRepository.getById(guestDetails.getAddress_id());
                for (BookingDetails bookingDetails : bookings) {
                    if (bookingDetails.getGuest_id() == guestDetails.getGuest_id() && bookingDetails.getCurrent_status() < CHECK_OUT) {
                        Booking bookingObj = convertObject(bookingDetails, guestDetails, adrOpt);
                        bookingList.add(bookingObj);
                        break;
                    }
                }

            }


        }else {

            //Not support now
        }
        return bookingList;
    }

    private Booking convertObject(BookingDetails bookingDetails, GuestDetails guestDetails, AddressDetails adrOpt) {
        Booking booking = new Booking();
        booking.setRoomType(bookingDetails.getRoom_type());
        booking.setToDate(bookingDetails.getTo_date().toString());
        booking.setName(guestDetails.getName());
        booking.setNumberOfRooms(bookingDetails.getNumber_of_rooms());
        booking.setContactNo(guestDetails.getContact_no());
        booking.setGuestId(guestDetails.getGuest_id());
        booking.setEmergencyContact(guestDetails.getEmergency_contact());
        booking.setBookingId(bookingDetails.getId());
        booking.setFromDate(bookingDetails.getFrom_date().toString());
        booking.setReservationDate(bookingDetails.getReservation_date().toString());
        booking.setAllocatedRoomList(bookingDetails.getAllocated_room_list());
        Address address = new Address();
        address.setCity(adrOpt.getCity());
        address.setCountry(adrOpt.getCountry());
        address.setZip(adrOpt.getZip());
        address.setLine1(adrOpt.getLine1());
        address.setLine2(adrOpt.getLine2());
        address.setLine3(adrOpt.getLine3());
        booking.setAddress(address);
        return booking;
    }

    public Booking checkIn(Booking booking) {

        for (DocumentDetails document : booking.getDocumentDetails()) {
            IdentificationDocumentDetails documentDetails = new IdentificationDocumentDetails();
            documentDetails.setBooking_id(booking.getBookingId());
            documentDetails.setGuest_id(booking.getGuestId());
            documentDetails.setAge(document.getAge());
            documentDetails.setName(document.getName());
            documentDetails.setId_type(document.getIdType());
            documentDetails.setId_number(document.getIdNumber());
            documentDetails = identificationDocumentRepository.save(documentDetails);
        }

        List<RoomAllocationDetails> list = roomAllocationDetailsRepository.findAll();
        for (RoomAllocationDetails roomAllocationDetails : list) {
            if (roomAllocationDetails.getRoom_type() == booking.getRoomType()) {
                List<String> rooms = Arrays.asList(roomAllocationDetails.getAvailability_list().split("\\s*,\\s*"));
                String selectedRooms = null;
                int i = 0;
                for (i = 0; i < booking.getNumberOfRooms(); i++) {
                    if (selectedRooms == null) {
                        selectedRooms = rooms.get(i);
                    } else {
                        selectedRooms += ("," + rooms.get(i));
                    }
                }
                String balanceRooms = null;
                for (; i < rooms.size(); i++) {
                    if (balanceRooms == null) {
                        balanceRooms = rooms.get(i);
                    } else {
                        balanceRooms += ("," + rooms.get(i));
                    }
                }
                booking.setAllocatedRoomList(selectedRooms);
                roomAllocationDetails.setAvailability_list(balanceRooms);
                roomAllocationDetailsRepository.save(roomAllocationDetails);
                BookingDetails bookingDetails = bookingDetailsRepository.getById(booking.getBookingId());
                bookingDetails.setAllocated_room_list(selectedRooms);
                bookingDetails.setCurrent_status(CHECK_IN);
                bookingDetailsRepository.save(bookingDetails);

            }
        }
        return booking;
    }

    public Booking checkOutOrCancel(Booking booking) {

        if(booking.getAllocatedRoomList() !=null ) {
            List<RoomAllocationDetails> list = roomAllocationDetailsRepository.findAll();
            for (RoomAllocationDetails roomAllocationDetails : list) {
                if (roomAllocationDetails.getRoom_type() == booking.getRoomType()) {
                    if (roomAllocationDetails.getAvailability_list() == null) {
                        roomAllocationDetails.setAvailability_list(booking.getAllocatedRoomList());
                    } else {
                        roomAllocationDetails.setAvailability_list(roomAllocationDetails.getAvailability_list() + "," + booking.getAllocatedRoomList());
                    }
                    roomAllocationDetailsRepository.save(roomAllocationDetails);
                    BookingDetails bookingDetails = bookingDetailsRepository.getById(booking.getBookingId());
                    bookingDetails.setCurrent_status(CHECK_OUT);
                    bookingDetailsRepository.save(bookingDetails);
                }
            }
        }else{
            BookingDetails bookingDetails = bookingDetailsRepository.getById(booking.getBookingId());
            bookingDetails.setCurrent_status(CANCEL);
            bookingDetailsRepository.save(bookingDetails);
        }
        return booking;
    }

    public ArrayList<PaymentTransactions> getPayments(PaymentTransactions paymentTransactions) {

        ArrayList<PaymentTransactions> list = new ArrayList<>();
        List<PaymentTransactionDetails> paymentList = paymentTransactionRepository.findByBookingId(paymentTransactions.getBookingId());
        for (PaymentTransactionDetails paymentTransactionDetails: paymentList ) {
            PaymentTransactions transactions = new PaymentTransactions();
            transactions.setPaymentId(paymentTransactionDetails.getId());
            transactions.setBookingId(paymentTransactionDetails.getPayment_mode());
            transactions.setGuestId(paymentTransactionDetails.getGuest_id());
            transactions.setAmount(paymentTransactionDetails.getAmount());
            transactions.setBalanceAmount(paymentTransactionDetails.getBalance_amount());
            transactions.setPaymentMode(paymentTransactionDetails.getPayment_mode());
            transactions.setRefund(paymentTransactionDetails.getIs_refund() == 1 ?true: false );
            transactions.setPaymentDate(paymentTransactionDetails.getPayment_date());
            list.add(transactions);
        }
        return list;
    }
}

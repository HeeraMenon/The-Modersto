package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.GuestDetails;
import com.hm.hotelmanagement.entity.RatingQuestions;
import com.hm.hotelmanagement.entity.ReviewAnswers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewQuestionRepository extends JpaRepository<RatingQuestions, Integer> {

    @Query( nativeQuery = true, value = "select * from rating_questions where key_word = :keyWord")
    RatingQuestions findByKeyWord(@Param("keyWord") String keyWord);

}

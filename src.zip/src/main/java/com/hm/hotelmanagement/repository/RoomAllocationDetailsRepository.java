package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.RoomAllocationDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoomAllocationDetailsRepository extends JpaRepository<RoomAllocationDetails, Integer> {
}

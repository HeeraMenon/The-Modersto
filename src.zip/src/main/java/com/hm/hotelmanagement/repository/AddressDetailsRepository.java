package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.AddressDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressDetailsRepository extends JpaRepository<AddressDetails, Integer> {

}

package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.GuestDetails;
import com.hm.hotelmanagement.entity.ReviewAnswers;
import com.hm.hotelmanagement.entity.RoomDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface ReviewDetailsRepository extends JpaRepository<ReviewAnswers, Integer> {

    @Query( nativeQuery = true, value = "select * from review_answers where question_id = :questionId and date >= :fromDate and date<= :toDate ")
    List<ReviewAnswers> getReport(@Param("questionId") int questionId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate );


    @Query( nativeQuery = true, value = "select * from review_answers where question_id = :questionId ORDER BY rating DESC limit 10 ")
    List<ReviewAnswers> getMaxReport(@Param("questionId") int questionId );

}

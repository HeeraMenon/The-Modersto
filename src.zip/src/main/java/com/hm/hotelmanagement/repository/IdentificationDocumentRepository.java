package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.IdentificationDocumentDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IdentificationDocumentRepository extends JpaRepository<IdentificationDocumentDetails, Integer> {
}

package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.BookingDetails;
import com.hm.hotelmanagement.entity.PaymentTransactionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface PaymentTransactionRepository extends JpaRepository<PaymentTransactionDetails, Integer> {

    @Query( nativeQuery = true, value = "select * from payment_transaction_details where booking_id = :bookingId ")
    List<PaymentTransactionDetails> findByBookingId(@Param("bookingId") int bookingId);

}

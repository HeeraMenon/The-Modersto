package com.hm.hotelmanagement.repository;

import com.hm.hotelmanagement.entity.BookingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetails, Integer> {

    @Query( nativeQuery = true, value = "select * from booking_details where current_status in (1,2) and from_date >= :fromDate and   to_date <= :toDate ")
    List<BookingDetails> findByDate(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);


}

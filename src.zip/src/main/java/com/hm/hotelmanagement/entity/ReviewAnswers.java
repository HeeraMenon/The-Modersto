package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class ReviewAnswers {


    /**
     * CREATE TABLE `review_answers` (
     *   `id` bigint NOT NULL,
     *   `question_id` bigint NOT NULL,
     *   `guest_id` bigint NOT NULL,
     *   `booking_id` bigint NOT NULL,
     *   `rating` int NOT NULL,
     *   `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     */

    public ReviewAnswers(int question_id, int guest_id, int booking_id, int rating, Date date) {
        this.question_id = question_id;
        this.guest_id = guest_id;
        this.booking_id = booking_id;
        this.rating = rating;
        this.date = date;
    }

    public ReviewAnswers() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public int question_id;
    public int guest_id;
    public int booking_id;
    public int rating;
    public Date date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuestion_id() {
        return question_id;
    }

    public void setQuestion_id(int question_id) {
        this.question_id = question_id;
    }

    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ReviewAnswers{" +
                "id=" + id +
                ", question_id=" + question_id +
                ", guest_id=" + guest_id +
                ", booking_id=" + booking_id +
                ", rating=" + rating +
                ", date=" + date +
                '}';
    }
}

package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RatingQuestions {

    /**
     * CREATE TABLE `rating_questions` (
     *   `id` bigint NOT NULL AUTO_INCREMENT,
     *   `question` varchar(100) NOT NULL,
     *   `key_word` varchar(100) NOT NULL,
     */

    public RatingQuestions(String question, String key_word) {
        this.question = question;
        this.key_word = key_word;
    }

    public RatingQuestions() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public String question;
    public String key_word;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    @Override
    public String toString() {
        return "RatingQuestions{" +
                "id=" + id +
                ", question='" + question + '\'' +
                ", key_word='" + key_word + '\'' +
                '}';
    }
}

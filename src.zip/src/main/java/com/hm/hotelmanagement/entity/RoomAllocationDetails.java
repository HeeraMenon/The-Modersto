package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RoomAllocationDetails {

    /**
     *   `id` int NOT NULL AUTO_INCREMENT,
     *   `room_type` int NOT NULL,
     *   `room_list` varchar(100) NOT NULL,
     *   `availability_list` varchar(100) DEFAULT NULL,
     */

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public int room_type;
    public String room_list;
    public String availability_list;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRoom_type() {
        return room_type;
    }

    public void setRoom_type(int room_type) {
        this.room_type = room_type;
    }

    public String getRoom_list() {
        return room_list;
    }

    public void setRoom_list(String room_list) {
        this.room_list = room_list;
    }

    public String getAvailability_list() {
        return availability_list;
    }

    public void setAvailability_list(String availability_list) {
        this.availability_list = availability_list;
    }
}

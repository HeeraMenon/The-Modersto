package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class IdentificationDocumentDetails {

    /**
     * CREATE TABLE `identification_document_details` (
     *   `id` bigint NOT NULL AUTO_INCREMENT,
     *   `id_number` varchar(100) NOT NULL,
     *   `id_type` int NOT NULL,
     *   `guest_id` bigint NOT NULL,
     *    `name` varchar(100) NOT NULL,
     *   `age` int NOT NULL,
     *   `booking_id` int NOT NULL,
     */

    public IdentificationDocumentDetails(String id_number, String id_type, int guest_id) {
        this.id_number = id_number;
        this.id_type = id_type;
        this.guest_id = guest_id;
    }

    public IdentificationDocumentDetails() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public String id_number;
    public String id_type;
    public int guest_id;

    public String name;

    public String age;

    public int booking_id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getId_number() {
        return id_number;
    }

    public void setId_number(String id_number) {
        this.id_number = id_number;
    }

    public String getId_type() {
        return id_type;
    }

    public void setId_type(String id_type) {
        this.id_type = id_type;
    }

    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    @Override
    public String toString() {
        return "IdentificationDocumentDetails{" +
                "id=" + id +
                ", id_number='" + id_number + '\'' +
                ", id_type='" + id_type + '\'' +
                ", guest_id=" + guest_id +
                '}';
    }
}

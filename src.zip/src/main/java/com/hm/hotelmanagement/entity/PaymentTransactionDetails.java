package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class PaymentTransactionDetails {
    public PaymentTransactionDetails() {
    }

    /**
     * CREATE TABLE `payment_transaction_details` (
     *   `id` bigint NOT NULL AUTO_INCREMENT,
     *   `booking_id` bigint NOT NULL,
     *   `guest_id` bigint NOT NULL,
     *   `amount` double NOT NULL DEFAULT '0',
     *   `balance_amount` double NOT NULL DEFAULT '0',
     *   `is_refund` tinyint(1) NOT NULL DEFAULT '0',
     *   `payment_mode` int NOT NULL DEFAULT '1',
     *   `remark` varchar(100) DEFAULT NULL,
     *   `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     */

    public PaymentTransactionDetails(int booking_id, int guest_id, float amount, float balance_amount, int is_refund, int payment_mode, String remark, Date payment_date) {
        this.booking_id = booking_id;
        this.guest_id = guest_id;
        this.amount = amount;
        this.balance_amount = balance_amount;
        this.is_refund = is_refund;
        this.payment_mode = payment_mode;
        this.remark = remark;
        this.payment_date = payment_date;
    }


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int id;
    public int booking_id;
    public int guest_id;
    public float amount;
    public float balance_amount;
    public int is_refund;
    public int payment_mode;
    public String remark;
    public Date payment_date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public float getBalance_amount() {
        return balance_amount;
    }

    public void setBalance_amount(float balance_amount) {
        this.balance_amount = balance_amount;
    }

    public int getIs_refund() {
        return is_refund;
    }

    public void setIs_refund(int is_refund) {
        this.is_refund = is_refund;
    }

    public int getPayment_mode() {
        return payment_mode;
    }

    public void setPayment_mode(int payment_mode) {
        this.payment_mode = payment_mode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(Date payment_date) {
        this.payment_date = payment_date;
    }

    @Override
    public String toString() {
        return "PaymentTransactionDetails{" +
                "id=" + id +
                ", booking_id=" + booking_id +
                ", guest_id=" + guest_id +
                ", amount=" + amount +
                ", balance_amount=" + balance_amount +
                ", is_refund=" + is_refund +
                ", payment_mode=" + payment_mode +
                ", remark='" + remark + '\'' +
                ", payment_date=" + payment_date +
                '}';
    }
}

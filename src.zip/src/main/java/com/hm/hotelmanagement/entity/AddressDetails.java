package com.hm.hotelmanagement.entity;

import javax.persistence.*;

@Entity
@Table(name="address_details")
public class AddressDetails {


    public AddressDetails() {
    }

    /**
     * `address_details` (
     *   `id` bigint NOT NULL AUTO_INCREMENT,
     *   `line1` varchar(100) NOT NULL,
     *   `line2` varchar(100) DEFAULT NULL,
     *   `line3` varchar(100) DEFAULT NULL,
     *   `city` varchar(100) NOT NULL,
     *   `country` varchar(100) NOT NULL,
     *   `zip` varchar(100) NOT NULL,
     */

    public AddressDetails(String line1, String line2, String line3, String city, String zip, String country) {
        this.line1 = line1;
        this.line2 = line2;
        this.line3 = line3;
        this.city = city;
        this.zip = zip;
        this.country = country;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public String line1;
    public String line2;
    public String line3;
    public String city;
    public String zip;
    public String country;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "AddressDetails{" +
                "id=" + id +
                ", line1='" + line1 + '\'' +
                ", line2='" + line2 + '\'' +
                ", line3='" + line3 + '\'' +
                ", city='" + city + '\'' +
                ", zip='" + zip + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}

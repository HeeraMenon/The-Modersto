package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class BookingDetails {

    public BookingDetails(Date from_date, Date to_date, int current_status, Date reservation_date, int number_of_rooms, int room_type, int guest_id, int payment_transaction_id, float current_balance, String remark) {
        this.from_date = from_date;
        this.to_date = to_date;
        this.current_status = current_status;
        this.reservation_date = reservation_date;
        this.number_of_rooms = number_of_rooms;
        this.room_type = room_type;
        this.guest_id = guest_id;
        this.payment_transaction_id = payment_transaction_id;
        this.current_balance = current_balance;
        this.remark = remark;
    }

    public BookingDetails() {
    }

    /**
     * CREATE TABLE `booking_details` (
     *   `id` bigint NOT NULL AUTO_INCREMENT,
     *   `from_date` date NOT NULL,
     *   `to_date` date DEFAULT NULL,
     *   `current_status` int NOT NULL DEFAULT '0',
     *   `reservation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     *   `number_of_rooms` int NOT NULL DEFAULT '1',
     *   `room_type` int NOT NULL DEFAULT '1',
     *   `guest_id` bigint NOT NULL,
     *   `payment_transaction_id` bigint NOT NULL,
     *   `current_balance` double NOT NULL DEFAULT '0',
     *   `remark` varchar(100) DEFAULT NULL,
     */



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public Date from_date;
    public Date to_date;
    public int current_status; //1-booked, 2- check-in, 3- check-out, 4-cancelled
    public Date reservation_date;
    public int number_of_rooms;
    public int room_type;
    public int guest_id;
    public int  payment_transaction_id;
    public float current_balance;
    public String remark;

    public String allocated_room_list;

    public String getAllocated_room_list() {
        return allocated_room_list;
    }

    public void setAllocated_room_list(String allocated_room_list) {
        this.allocated_room_list = allocated_room_list;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFrom_date() {
        return from_date;
    }

    public void setFrom_date(Date from_date) {
        this.from_date = from_date;
    }

    public Date getTo_date() {
        return to_date;
    }

    public void setTo_date(Date to_date) {
        this.to_date = to_date;
    }

    public int getCurrent_status() {
        return current_status;
    }

    public void setCurrent_status(int current_status) {
        this.current_status = current_status;
    }

    public Date getReservation_date() {
        return reservation_date;
    }

    public void setReservation_date(Date reservation_date) {
        this.reservation_date = reservation_date;
    }

    public int getNumber_of_rooms() {
        return number_of_rooms;
    }

    public void setNumber_of_rooms(int number_of_rooms) {
        this.number_of_rooms = number_of_rooms;
    }

    public int getRoom_type() {
        return room_type;
    }

    public void setRoom_type(int room_type) {
        this.room_type = room_type;
    }

    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    public int getPayment_transaction_id() {
        return payment_transaction_id;
    }

    public void setPayment_transaction_id(int payment_transaction_id) {
        this.payment_transaction_id = payment_transaction_id;
    }

    public float getCurrent_balance() {
        return current_balance;
    }

    public void setCurrent_balance(float current_balance) {
        this.current_balance = current_balance;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "BookingDetails{" +
                "id=" + id +
                ", from_date=" + from_date +
                ", to_date=" + to_date +
                ", current_status=" + current_status +
                ", reservation_date=" + reservation_date +
                ", number_of_rooms=" + number_of_rooms +
                ", room_type=" + room_type +
                ", guest_id=" + guest_id +
                ", payment_transaction_id=" + payment_transaction_id +
                ", current_balance=" + current_balance +
                ", remark='" + remark + '\'' +
                '}';
    }
}

package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RoomDetails {
    /**
     *
     CREATE TABLE `room_details` (
     `id` int NOT NULL AUTO_INCREMENT,
     `type` int NOT NULL,
     `room_count` int NOT NULL,
     `series` varchar(100) NOT NULL,
     */

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public int type;
    public int room_count;
    public String series;
    public int capacity;

    public int rent;

    public int getRent() {
        return rent;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getRoom_count() {
        return room_count;
    }

    public void setRoom_count(int room_count) {
        this.room_count = room_count;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "RoomDetails{" +
                "id=" + id +
                ", type=" + type +
                ", room_count=" + room_count +
                ", series='" + series + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}

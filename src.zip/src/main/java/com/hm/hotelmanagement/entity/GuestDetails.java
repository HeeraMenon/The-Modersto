package com.hm.hotelmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class GuestDetails {

     /**
     * CREATE TABLE `guest_details` (
     *   `guest_id` bigint NOT NULL AUTO_INCREMENT,
     *   `name` varchar(100) NOT NULL,
     *   `address_id` bigint NOT NULL,
     *   `contact_no` varchar(100) NOT NULL,
     *   `contact_email` varchar(100) DEFAULT NULL,
     *   `emergency_contact` varchar(100) NOT NULL,
     *   `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     */

     public GuestDetails(String name, int address_id, String contact_no, String contact_email, Date created_date) {
         this.name = name;
         this.address_id = address_id;
         this.contact_no = contact_no;
         this.contact_email = contact_email;
         this.created_date = created_date;
     }

    public GuestDetails() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int guest_id;
    public String name;
    public int address_id;
    public String contact_no;
    public String contact_email;
    public Date created_date;

    public String getEmergency_contact() {
        return emergency_contact;
    }

    public void setEmergency_contact(String emergency_contact) {
        this.emergency_contact = emergency_contact;
    }

    public String emergency_contact;


    public int getGuest_id() {
        return guest_id;
    }

    public void setGuest_id(int guest_id) {
        this.guest_id = guest_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAddress_id() {
        return address_id;
    }

    public void setAddress_id(int address_id) {
        this.address_id = address_id;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getContact_email() {
        return contact_email;
    }

    public void setContact_email(String contact_email) {
        this.contact_email = contact_email;
    }

    public Date getCreated_date() {
        return created_date;
    }

    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }

    @Override
    public String toString() {
        return "GuestDetails{" +
                "guest_id=" + guest_id +
                ", name='" + name + '\'' +
                ", address_id=" + address_id +
                ", contact_no='" + contact_no + '\'' +
                ", contact_email='" + contact_email + '\'' +
                ", created_date=" + created_date +
                '}';
    }
}
